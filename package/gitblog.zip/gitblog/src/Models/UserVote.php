<?php

namespace Onu\Gitblog\Models;

use Illuminate\Database\Eloquent\Model;

class UserVote extends Model
{
    //
}
