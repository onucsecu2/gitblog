<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContributionView extends Model
{
    //
}
